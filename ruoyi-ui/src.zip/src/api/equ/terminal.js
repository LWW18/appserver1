import request from '@/utils/request'

// 查询终端列表
export function listTerminal(query) {
  return request({
    url: '/equ/terminal/list',
    method: 'get',
    params: query
  })
}

// 查询终端详细
export function getTerminal(snId) {
  return request({
    url: '/equ/terminal/' + snId,
    method: 'get'
  })
}

// 新增终端
export function addTerminal(data) {
  return request({
    url: '/equ/terminal',
    method: 'post',
    data: data
  })
}

// 修改终端
export function updateTerminal(data) {
  return request({
    url: '/equ/terminal',
    method: 'put',
    data: data
  })
}

// 删除终端
export function delTerminal(snId) {
  return request({
    url: '/equ/terminal/' + snId,
    method: 'delete'
  })
}

// 查询App
export function appSelect() {
  return request({
    url: '/equ/terminal/appList',
    method: 'get'
  })
}

// 终端类型
export function terminalType(query) {
  return request({
    url: '/equ/terminal/terlist',
    method: 'get',
    params: query
  })
}

// 终端状态
export function runStateList(query) {
  return request({
    url: '/equ/terminal/runStateList',
    method: 'get',
    params: query
  })
}
