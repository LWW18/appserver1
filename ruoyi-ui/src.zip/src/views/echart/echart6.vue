<template>
  <div class="box" ref="box" style="width: 100%; height: 400px" />
</template>

<script>
import echarts from "echarts";
require("echarts/theme/macarons"); // echarts theme

export default {
  data() {
    return {
      // 指定图表的配置项和数据
      option: {
        title: {
          text: "App访问量",
          left: "center",
          top: "3%",
          textStyle: {
            //标题内容的样式
            fontSize: 19,
            color: "black",
            fontWeight: "bold",
          },
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            // 坐标轴指示器，坐标轴触发有效
            type: "shadow", // 默认为直线，可选为：'line' | 'shadow'
          },
        },
        legend: {
          data: ["近七日访问量"],
          x: "right",
          y: "top",
          padding: [45, 100, 0, 0],
        },
        xAxis: {
          data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        },
        yAxis: {
          name: "数量（次）",
          nameTextStyle: {
            color: "black",
            nameLocation: "start",
          },
        },
        toolbox: {
          // 工具箱
          show: true,
          feature: {
            dataView: { readOnly: false },
            magicType: { type: ["bar", "line"] },
            restore: {},
          },
        },
        series: [
          {
            name: "近七日访问量",
            type: "line",
            stack: "vistors",
            barWidth: "60%",
            data: ["172", "193", "301", "374", "275", "211", "354"],
            markLine: {
              data: [{ type: "average", name: "平均值" }],
              label: {
                position: "end",
                formatter: "{b}：\n" + "{c}",
              },
            },
            color: {
              x: 0,
              y: 0,
              x2: 0,
              y2: 1,
              colorStops: [
                {
                  offset: 0,
                  color: "#39b8dc", // 0% 处的颜色
                },
                {
                  offset: 1,
                  color: "#4bbecc", // 100% 处的颜色
                },
              ],
              global: false, // 缺省为 false
            },
          },
        ],
      },
    };
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart();
    });
  },
  methods: {

    initChart() {
      let chart = echarts.init(this.$refs.box, "macarons");
      // this.chart = echarts.init(this.$el)

      // 使用刚指定的配置项和数据显示图表。
      chart.setOption(this.option);

      // window.addEventListener("resize", function () {
      //   chart.resize();
      // });
      // //  随外层div的大小变化自适应
      // const _this = this;
      // let erd = elementResizeDetectorMaker();
      // erd.listenTo(this.$refs.box, () => {
      //   _this.$nextTick(() => {
      //     chart.resize();
      //   });
      // });
    },
    // resetCharts() {
    //   this.$echarts.init(this.$refs.box).resize();
    // }
  },
};
</script>
<style lang="css" scoped>
.chart {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  width: 100%;
  height: 400px;
}
</style>

