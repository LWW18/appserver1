<template>
  <div class="echart" id="mychart" :style="myChartStyle"></div>
</template>

<script>
import * as echarts from "echarts";
export default {
  data() {
    return {
      xData: ["App1", "App2", "App3", "App4", "App5", "App6", "App7"], //横坐标
      yData: [10, 11, 9, 17, 14, 13, 14],
      // taskDate: [23, 24, 18, 25, 27, 28, 25],
      myChartStyle: { float: "left", width: "100%", height: "400px" }, //图表样式
    };
  },
  mounted() {
    this.initEcharts();
  },
  methods: {
    initEcharts() {
      // 多列柱状图
      const mulColumnZZTData = {
        xAxis: {
          data: this.xData,
        },
        // 图例
        legend: {
          data: ["各App终端数量",],
          top: "5%",
        },
        yAxis: {
          type: "value",
          splitLine: {
            show: true,
          },
          axisLine: {
            //坐标轴
            show: false,
          },
          axisLabel: { show: true },
          axisTick: {
            //刻度线
            show: false,
            alignWithLabel: true,
          },
        },
        series: [
          {
            type: "bar", //形状为柱状图
            data: this.yData,
            name: "各App终端数量", // legend属性
            label: {
              // 柱状图上方文本标签，默认展示数值信息
              show: true,
              position: "top",
            },
            itemStyle: {
              color: "#91cc75",
              shadowColor: "#91cc75",
              borderType: "dashed",
              opacity: 0.75,
            },
          },
          {
            type: "bar", //形状为柱状图
            data: this.taskDate,
            name: "周访问量", // legend属性
            label: {
              // 柱状图上方文本标签，默认展示数值信息
              show: true,
              position: "top",
            },
            itemStyle: {
              color: "#59a4da",
              shadowColor: "#59a4da",
              borderType: "dashed",
              opacity: 0.75,
            },
          },
        ],
      };
      const myChart = echarts.init(document.getElementById("mychart"));
      myChart.setOption(mulColumnZZTData);
      //随着屏幕大小调节图表
      window.addEventListener("resize", () => {
        myChart.resize();
      });
    },
  },
};
</script>

