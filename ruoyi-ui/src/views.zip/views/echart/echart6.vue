<template>
  <!--为echarts准备一个具备大小的容器dom-->
  <div id="main" style="width: 725px; height: 380px"></div>
</template>
<script>
import echarts from "echarts";
export default {
  name: "",
  data() {
    return {
      charts: "",
      // opinion: ["172", "193", "301", "374", "275","211","354"],
      // opinionData: ["200", "154", "428", "331", "286", "344", "336"],
    };
  },
  methods: {
    drawLine(id) {
      this.charts = echarts.init(document.getElementById(id));
      this.charts.setOption({
        tooltip: {
          trigger: "axis",
        },
        legend: {
          data: ["今日访问量","昨日访问量"],
          top: "5%",
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },

        toolbox: {
          feature: {
            saveAsImage: {},
          },
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: ["App1", "App2", "App3", "App4", "App5", "App6", "App7"],
        },
        yAxis: {
          type: "value",
        },

        series: [
          {
            name: "今日访问量",
            type: "line",
            data:["172", "193", "301", "374", "275","211","354"],
            areaStyle: {
              normal: {
                color: {
                  type: "linear",
                  x: 0,
                  y: 0,
                  x2: 0,
                  y2: 1,
                  colorStops: [
                    {
                      offset: 0,
                      color: "#39b8dc", // 0% 处的颜色
                    },
                    {
                      offset: 1,
                      color: "#c2e9f7", // 100% 处的颜色
                    },
                  ],
                  global: false, // 缺省为 false
                },
              },
            },
            itemStyle: {
              normal: {
                color: "#59a4da", //改变折线点的颜色
                lineStyle: {
                  color: "#59a4da", //改变折线颜色
                },
              },
            },
          },
          {
            name: "昨日访问量",
            type: "line",
            data: ["200", "154", "428", "231", "211", "344", "336"],
            areaStyle: {
              normal: {
                color: {
                  type: "linear",
                  x: 0,
                  y: 0,
                  x2: 0,
                  y2: 1,
                  colorStops: [
                    {
                      offset: 0,
                      color: "#5ac4bd", // 0% 处的颜色
                    },
                    {
                      offset: 1,
                      color: "#ade2de", // 100% 处的颜色
                    },
                  ],
                  global: false, // 缺省为 false
                },
              },
            },
            itemStyle: {
              normal: {
                color: "#5ac4bd", //改变折线点的颜色
                lineStyle: {
                  color: "#5ac4bd", //改变折线颜色
                },
              },
            },
          },
        ],
      });
    },
  },
  //调用
  mounted() {
    this.$nextTick(function () {
      this.drawLine("main");
    });
  },
};
</script>
<style scoped>
* {
  margin: 0;
  padding: 0;
  list-style: none;
}
</style>