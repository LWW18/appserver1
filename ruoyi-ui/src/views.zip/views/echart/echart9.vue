<template>
  <div>
    <div
      id="chart2"
      :style="{ width: '400px', height: '180px', padding: '5px' }"
    ></div>
    <div>
      <div class="right">
        <span class="chart-text">预警总数量:  {{  }}  条</span
        ><br />
        <span class="chart-text">XX数量:  {{  }}  条</span
        ><br />
        <span class="chart-text">XX数量:  {{  }}  条</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      datas: [
        {
          value: 435,
          name: "预警",
        },
        {
          value: 310,
          name: "安全",
          label: {
            show: false,
          },
        },
      ],
    };
  },
  mounted() {
    this.showChart();
  },
  created() {},
  methods: {
    showChart() {
      var chart = this.$echarts.init(document.getElementById("chart2"));
      var option = {
        color: ["#ec808c", "#eeeeee"],
        title: {
          text: "预警数量",
          textStyle: {
            fontSize: 22,
          },
          left: "2%",
          top: "5%",
        },
        series: [
          {
            name: "数据展示",
            type: "pie",
            radius: ["50%", "70%"],
            left: "50px",
            avoidLabelOverlap: false,
            hoverAnimation: false, //关闭放大动画
            selectedOffset: 0, //选中块的偏移量
            label: {
              show: true,
              position: "center",
              formatter: "{d}%",
              fontSize: "20",
              fontWeight: "bold",
            },
            emphasis: {
              label: {
                show: true,
                fontSize: "20",
                fontWeight: "bold",
              },
            },
            labelLine: {
              show: false,
            },
            data: this.datas,
          },
        ],
      };

      chart.setOption(option);
    },
  },
};
</script>
<style lang='css' scoped>
.right {
  position: absolute;
  top: 40px;
  left: 430px;
  width: 360px;
  height: 180px;
}
.chart-text {
  display: inline-block;
  font-size: 18px;
  font-weight: bold;
  margin: 10px 0;
  color: rgba(100, 99, 99, 0.753);
}
</style>