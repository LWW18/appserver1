<template>
  <div>
    <div
      id="treeChart"
      :style="{ width: '100%', height: '500px', padding: '30px' }"
    ></div>
  </div>
</template>

<script>
import { listTerminal } from "@/api/equ/terminal";
export default {
  name: "Topology",
  data() {
    return {
      getGwEuiList: [],
      euiList: [],
      gwEui: null,
      treedata: [
        {
          //一定一定要注意这里有[]
          appname: "App",
          children: [
            {
              gwEui: "网关EUI",
              children: [
                {
                  name: "终端EUI",
                  children: [
                    {
                      name: "传感器ID",
                    },
                    {
                      name: "传感器ID",
                    },
                    {
                      name: "传感器ID",
                    },
                  ],
                },
                {
                  name: "终端EUI",
                  children: [
                    {
                      name: "传感器ID",
                    },
                    {
                      name: "传感器ID",
                    },
                    {
                      name: "传感器ID",
                    },
                  ],
                },
                {
                  name: "终端EUI",
                },
              ],
            },
            {
              gwEui: "网关EUI",
              children: [
                {
                  name: "终端EUI",
                },
                {
                  name: "终端EUI",
                },
              ],
            },
            {
              gwEui: "网关EUI",
              children: [
                {
                  name: "终端EUI",
                },
              ],
            },
            {
              gwEui: "网关EUI",
              children: [
                {
                  name: "终端EUI",
                  children: [
                    {
                      name: "传感器ID",
                    },
                    {
                      name: "传感器ID",
                    },
                    {
                      name: "传感器ID",
                    },
                  ],
                },
              ],
            },
            {
              gwEui: "网关名称5",
              children: [
                {
                  name: "终端EUI",
                  children: [
                    {
                      name: "传感器ID",
                    },
                    {
                      name: "传感器ID",
                    },
                    {
                      name: "传感器ID",
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    };
  },
  mounted() {
    this.showChart();
  },
  // created() {
  //   listTerminal(this.queryParams).then((response) => {
  //     //   console.log(response);
  //     // this.treedata.length = 0; //清空数组
  //     this.getGwEuiList = response.rows;
  //     console.log(this.getGwEuiList);
  //     for (let i = 0; i < this.getGwEuiList.length; i++) {
  //       // this.euiList.push(this.getGwEuiList[i].gatewayEui);
  //       var children2 = [{
  //           gwEui : this.getGwEuiList[i].gatewayEui,
  //       }]
  //       var children3 = [
  //           {terEui : this.getGwEuiList[i].terminalEui},
  //           // value= this.euiList[i],
  //       ];
  //       var children4 =[{
  //         senName : this.getGwEuiList[i].sensorId,
  //       }]
  //       children3.push(children4)
  //       children2.push(children3);
  //       this.treedata[0].children.push(children2);
  //     }
     
  //     console.log(this.treedata);
     
      
  //   });
  // },
  
  methods: {
    showChart() {
      // 基于准备好的dom，初始化echarts实例
      var myChart = this.$echarts.init(document.getElementById("treeChart"));

      // 指定图表的配置项和数据
      var option = {
        title: {
          text: "网关拓扑结构",
        },
        tooltip: {
          trigger: "item",
          triggerOn: "mousemove",
        },
        series: [
          {
            type: "tree",
            data: this.treedata,
            top: "1%",
            left: "7%",
            bottom: "1%",
            right: "20%",

            symbolSize: 7,

            label: {
              position: "left",
              verticalAlign: "middle",
              align: "right",
              fontSize: 13,
            },

            leaves: {
              label: {
                position: "right",
                verticalAlign: "middle",
                align: "left",
              },
            },

            expandAndCollapse: true,
            animationDuration: 550,
            animationDurationUpdate: 750,
          },
        ],
      };
      // 使用刚指定的配置项和数据显示图表。
      myChart.setOption(option);
    },
  },
};
</script>

<style scoped>
.ml30 {
  margin-left: 30px;
}
.m50 {
  margin: 50px;
}
</style>

